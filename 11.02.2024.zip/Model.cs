namespace F_2;

public class Model
{
    public string mavzu { get; set; }
    public DateTime start_date { get; set; }
    public int students_count { get; set; }
}