﻿using System;
using System.Collections.Generic;
using Npgsql;

namespace F_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string CONNECTIONSTRING = "Server=localhost;Port=5432;Database=exam;Username=postgres;Password=2712;";

            NpgsqlConnection connection = new NpgsqlConnection(CONNECTIONSTRING);

            connection.Open();

            CreateTable(connection);
            InsertSingleRecord(connection);
            InsertMultipleRecords(connection);
            GetAllRecords(connection);
            
            int idToFind = 1; // You can change this to the desired ID
            GetById(connection, idToFind);
            
            string mavzuToUpdate = "ADO .NET";
            int newStudentsCount = 30;
            UpdateRecord(connection, mavzuToUpdate, newStudentsCount);

            UpdateColumn(connection, mavzuToUpdate, "start_date", DateTime.Now.AddDays(1));

            string searchTerm = "Post";
            SearchByColumn(connection, "mavzu", searchTerm);

            AddNewColumn(connection, "new_column", "text", "default_value");
            UpdateColumnName(connection, "new_column", "new_column_updated");
            UpdateTableName(connection, "skypedars", "skypedars_updated");
            TruncateTable(connection, "skypedars_updated");

            connection.Close();
        }

        static void CreateTable(NpgsqlConnection connection)
        {
            string tableName = "skypedars_updated"; 
            string checkTableExistenceQuery = $"SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = '{tableName}')";

            using (NpgsqlCommand checkTableExistenceCommand = new NpgsqlCommand(checkTableExistenceQuery, connection))
            {
                bool tableExists = (bool)checkTableExistenceCommand.ExecuteScalar();

                if (!tableExists)
                {
                    string createTableQuery = $"create table {tableName}(id serial, mavzu varchar(40), start_date date, students_count int);";
                    ExecuteQuery(connection, createTableQuery);
                }
                else
                {
                    Console.WriteLine($"Table '{tableName}' already exists.");
                }
            }
        }



        static void InsertSingleRecord(NpgsqlConnection connection)
        {
            Model table = new Model();
            table.mavzu = "ADO .NET";
            table.start_date = DateTime.Now;
            table.students_count = 25;

            InsertRecord(connection, table);
        }

        static void InsertMultipleRecords(NpgsqlConnection connection)
        {
            IList<Model> datalar = new List<Model>()
            {
                new Model() { mavzu = "MongoDB", start_date = DateTime.Now, students_count = 45 },
                new Model() { mavzu = "PostgreSQL", start_date = DateTime.Now, students_count = 20 },
                new Model() { mavzu = "Provayderlar bilan ishlash", start_date = DateTime.Now, students_count = 90 },
            };

            foreach (var data in datalar)
            {
                InsertRecord(connection, data);
            }
        }

        static void GetAllRecords(NpgsqlConnection connection)
        {
            string selectAllQuery = "select * from skypedars_updated"; 
            using (NpgsqlCommand selectCommand = new NpgsqlCommand(selectAllQuery, connection))
            {
                using (NpgsqlDataReader reader = selectCommand.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"ID: {reader["id"]}, Mavzu: {reader["mavzu"]}, Start Date: {reader["start_date"]}, Students Count: {reader["students_count"]}");
                    }
                }
            }
        }

        static void GetById(NpgsqlConnection connection, int id)
        {
            string getByIdQuery = $"select * from skypedars_updated where id = {id}";
            using (NpgsqlCommand selectCommand = new NpgsqlCommand(getByIdQuery, connection))
            {
                using (NpgsqlDataReader reader = selectCommand.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"ID: {reader["id"]}, Mavzu: {reader["mavzu"]}, Start Date: {reader["start_date"]}, Students Count: {reader["students_count"]}");
                    }
                }
            }
        }
        
        static void InsertRecord(NpgsqlConnection connection, Model data)
        {
            string insertQuery = $"insert into skypedars_updated(mavzu, start_date, students_count) values " +
                                 $"('{data.mavzu}', '{data.start_date}', {data.students_count})";
            ExecuteQuery(connection, insertQuery);
        }

        static void UpdateRecord(NpgsqlConnection connection, string mavzu, int newStudentsCount)
        {
            string updateQuery = "update skypedars_updated set students_count = @students_count where mavzu = @mavzu";
            using (NpgsqlCommand updateCommand = new NpgsqlCommand(updateQuery, connection))
            {
                updateCommand.Parameters.AddWithValue("@students_count", newStudentsCount);
                updateCommand.Parameters.AddWithValue("@mavzu", mavzu);
                updateCommand.ExecuteNonQuery();
            }
        }

        static void UpdateColumn(NpgsqlConnection connection, string mavzu, string columnName, object newValue)
        {
            string updateColumnQuery = $"update skypedars_updated set {columnName} = @new_value where mavzu = @mavzu";
            using (NpgsqlCommand updateColumnCommand = new NpgsqlCommand(updateColumnQuery, connection))
            {
                updateColumnCommand.Parameters.AddWithValue("@new_value", newValue);
                updateColumnCommand.Parameters.AddWithValue("@mavzu", mavzu);
                updateColumnCommand.ExecuteNonQuery();
            }
        }

        static void SearchByColumn(NpgsqlConnection connection, string columnName, string searchTerm)
        {
            string searchQuery = $"select * from skypedars_updated where {columnName} LIKE '%{searchTerm}%'";
            ExecuteQuery(connection, searchQuery);
        }

        static void AddNewColumn(NpgsqlConnection connection, string columnName, string columnType, string defaultValue)
        {
            string addColumnQuery = $"alter table skypedars_updated add column {columnName} {columnType} default '{defaultValue}'";
            ExecuteQuery(connection, addColumnQuery);
        }

        static void UpdateColumnName(NpgsqlConnection connection, string oldColumnName, string newColumnName)
        {
            string updateColumnNameQuery = $"alter table skypedars_updated rename column {oldColumnName} to {newColumnName}";
            ExecuteQuery(connection, updateColumnNameQuery);
        }

        static void UpdateTableName(NpgsqlConnection connection, string oldTableName, string newTableName)
        {
            string updateTableNameQuery = $"alter table {oldTableName} rename to {newTableName}";
            ExecuteQuery(connection, updateTableNameQuery);
        }

        static void TruncateTable(NpgsqlConnection connection, string tableName)
        {
            string truncateTableQuery = $"truncate table {tableName}";
            ExecuteQuery(connection, truncateTableQuery);
        }

        static void ExecuteQuery(NpgsqlConnection connection, string query)
        {
            using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
            {
                command.ExecuteNonQuery();
            }
        }
    }
}

